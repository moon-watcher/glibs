#include "genesis.h"

/* masks for joystick functions */

#define sp_START		0x0100
#define sp_FIRE			0x0080
#define sp_RIGHT		0x0008
#define sp_LEFT			0x0004
#define sp_DOWN			0x0002
#define sp_UP			0x0001

/* sprite types */

#define sp_MASK_SPRITE	0x00

/* Colour Attributes */

#define TRANSPARENT		0x80

/* Clear Rectangle Flags */

#define sp_CR_TILES		0x01

/* Print String Struct Flags */

#define sp_PSS_INVALIDATE	0x01

/* SP's Sprite Struct */

struct sp_SS {
   u8 active;
   i16 ptr;
   i16 x;
   i16 y;
   u16 tile;
};

/* Small Rectangles with 8-bit coordinates (used by SP where units are characters) */

struct sp_Rect {
   u8 row_coord;     /* coordinate of top left corner */
   u8 col_coord;
   u8 height;        /* size */
   u8 width;
};

u8 sp_tile_buf[32*24];
u8 sp_attr_buf[32*24];

#define SPRITES_MAX	20

struct sp_SS spriteList[SPRITES_MAX];

u16 spriteBuf[SPRITES_MAX*4];


void sp_Init(void)
{
	i16 i;
	
	for(i=0;i<32*24;i++)
	{
		sp_tile_buf[i]=0;
		sp_attr_buf[i]=0;
	}
	
	for(i=0;i<SPRITES_MAX;i++) spriteList[i].active=FALSE;
	for(i=0;i<sizeof(spriteBuf);i++) spriteBuf[i]=0;
}

void sp_AttrSet(i16 x,i16 y,u8 a)
{
	if(y<24) sp_attr_buf[(y<<5)+x]=a;
}

u8 sp_AttrGet(i16 x,i16 y)
{
	return (y<24?sp_attr_buf[(y<<5)+x]:0);
}

void sp_TileSet(i16 col,i16 row,u16 tile)
{
    volatile u32 *pl;
    volatile u16 *pw;
    u32 adr;

    adr=PLANE_A_ADR+(((row+2)*PLANE_WDT+col)<<1);

    if(tile>80) tile+=PALETTE_NUM(3); else if(tile>48) tile+=PALETTE_NUM(2); else tile+=PALETTE_NUM(1);
    if(row<2||row>=22||col<2||col>=30) tile|=0x8000;
    
    pl=(u32*)GFXCNTL;
    pw=(u16*)GFXDATA;
    *pl=GFX_WRITE_VRAM((u32)adr);
    *pw=tile;
}

/* background tiles */

void sp_PrintAtInv(u8 row, u8 col, u8 colour, u8 udg)
{
    i16 ptr;
    
    ptr=(row<<5)+col;
    sp_attr_buf[ptr]=colour;
    sp_tile_buf[ptr]=udg;
    sp_TileSet(col,row,udg);
}

void sp_GetTiles(struct sp_Rect *r, u8 *dest)
{
	u16 i,j,ptr;
	
	ptr=(r->row_coord<<5)+r->col_coord;
	
	for(i=0;i<r->height;i++)
	{
		for(j=0;j<r->width;j++)
		{
			*dest++=sp_tile_buf[ptr++];
		}
		ptr+=(32-r->width);
	}
}

void sp_PutTiles(struct sp_Rect *r, u8 *src)
{
	u16 i,j,ptr;
	
	ptr=(r->row_coord<<5)+r->col_coord;
	
	for(i=0;i<r->height;i++)
	{
		for(j=0;j<r->width;j++)
		{
			sp_tile_buf[ptr]=*src++;
			sp_TileSet(r->col_coord+j,r->row_coord+i,sp_tile_buf[ptr++]);
		}
		ptr+=(32-r->width);
	}
}

/* sprites */

struct sp_SS *sp_CreateSpr(u8 type, u8 rows, u16 graphic, u8 plane, u8 extra)
{
	u16 i;
	
	for(i=0;i<SPRITES_MAX;i++)
	{
		if(!spriteList[i].active)
		{
		    spriteList[i].active=TRUE;
		    spriteList[i].ptr=i;
		    spriteList[i].x=0;
		    spriteList[i].y=0;
		    spriteList[i].tile=graphic;
		    return &spriteList[i];
    	}
    }
    
    return NULL;
}

void sp_MoveSprAbs(struct sp_SS *sprite, struct sp_Rect *clip, u16 animate, u8 row, u8 col, u8 hpix, u8 vpix)
{
	if(sprite)
	{
		if(animate<33+16) animate+=PALETTE_NUM(1);
		if(row<24)
		{
			sprite->x=(col<<3)+hpix+(col?128:0);
			sprite->y=(row<<3)+vpix+(col?128+16:0);
		}
		sprite->tile=animate;
	}
}

void sp_DeleteSpr(struct sp_SS *sprite)
{
	if(sprite)
	{
		sprite->active=FALSE;
	}
}

/* updater */

void sp_UpdateNow(void)
{
	u16 i,link,cnt;
	u16 *buf;
	
    link=1;
	cnt=0;
	buf=spriteBuf;
	
	for(i=0;i<SPRITES_MAX;i++) if(spriteList[i].active) cnt++;
	
	if(!cnt)
	{
		*buf++=0;
		*buf++=0;
		*buf++=0;
		*buf++=0;
	}
	
	for(i=0;i<SPRITES_MAX;i++)
	{
        if(!spriteList[i].active) continue;
        cnt--;
        if(cnt==0) link=0;
        *buf++=spriteList[i].y;
        *buf++=0x0500|link;
        *buf++=spriteList[i].tile;
        *buf++=spriteList[i].x;
        link++;
	}

 	wait_sync();
	update_palette();
	vram_copy(SPRITES_ADR,spriteBuf,sizeof(spriteBuf));
}

void sp_ClearRect(struct sp_Rect *area, u8 colour, u8 udg, u8 flags)
{
	u16 i,j;
	
	for(i=0;i<24;i++)
	{
		for(j=0;j<32;j++)
		{
			sp_PrintAtInv(i,j,0,0);
		}
	}
}

/* input */

u8 sp_GetKey(void)
{
    return (read_gamepad()&(BUTTON_A|BUTTON_B|BUTTON_C|BUTTON_S))?1:0;
}

/* additional stuff */

void sp_SetSpriteClip(struct sp_Rect *clip)
{
    struct sp_Rect empty;
    u16 i;
    
    empty.col_coord=0;
    empty.row_coord=0;
    empty.width=32;
    empty.height=24;
    
    if(!clip) clip=&empty;

    for(i=0;i<28;i++)
    {
	    vram_fill(PLANE_B_ADR+((i*PLANE_WDT)<<1),0x8000+112+PALETTE_NUM(3),32,0);
    }
    
    for(i=0;i<clip->height;i++)
    {
	    vram_fill(PLANE_B_ADR+(((clip->row_coord+2+i)*PLANE_WDT+clip->col_coord)<<1),0,clip->width,0);
    }
}

void sp_HideAllSpr(void)
{
	u16 i;
	
	for(i=0;i<SPRITES_MAX;i++)
	{
		if(spriteList[i].active)
		{
			spriteList[i].x=0;
			spriteList[i].y=0;
		}
	}
	sp_UpdateNow();
}
