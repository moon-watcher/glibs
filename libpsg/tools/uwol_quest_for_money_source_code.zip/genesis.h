#define GFXDATA 		0xc00000
#define GFXCNTL 		0xc00004

#define Z80_HALT  		0xa11100
#define Z80_RESET 		0xa11200

#define PSG_DATA		0xc00011

#define HW_VER			0xa10000

#define PORT_DATA1		0xa10003
#define PORT_CTRL1		0xa10009

#define YM2612_A0   	0xa04000
#define YM2612_D0   	0xa04001
#define YM2612_A1   	0xa04002
#define YM2612_D1   	0xa04003

#define JOY_UP          0x01
#define JOY_DOWN        0x02
#define JOY_LEFT        0x04
#define JOY_RIGHT       0x08
#define BUTTON_A        0x40
#define BUTTON_B        0x10
#define BUTTON_C        0x20
#define BUTTON_S        0x80
#define BUTTON_ABC		(BUTTON_A|BUTTON_B|BUTTON_C)
#define BUTTON_ABCS		(BUTTON_ABC|BUTTON_S)


#define GFX_DMA_VRAM(adr)      ((0x4000+((adr)&0x3FFF))<<16)+(((adr)>>14)|0x80)
#define GFX_WRITE_VRAM(adr)    ((0x4000+((adr)&0x3FFF))<<16)+(((adr)>>14)|0x00)
#define GFX_WRITE_CRAM(adr)    ((0xC000+((adr)&0x3FFF))<<16)+(((adr)>>14)|0x00)
#define GFX_WRITE_VSRAM(adr)   ((0x4000+((adr)&0x3FFF))<<16)+(((adr)>>14)|0x10)


typedef char  i8;
typedef short i16;
typedef long  i32;
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

#ifndef FALSE
#define FALSE   0
#endif
#ifndef TRUE
#define TRUE    1
#endif
#ifndef NULL
#define NULL    0
#endif

#define SCREEN_CHR_WDT  32
#define SCREEN_CHR_HGT  28
#define SCREEN_PIX_WDT  (SCREEN_CHR_WDT<<3)
#define SCREEN_PIX_HGT  (SCREEN_CHR_HGT<<3)
#define PLANE_A_ADR     0xe000
#define PLANE_B_ADR     0xc000
#define PLANE_WDT       32
#define PLANE_HGT       32
#define PLANE_WDT_MASK  (PLANE_WDT-1)
#define PLANE_HGT_MASK  (PLANE_HGT-1)
#define SPRITES_ADR     0xfc00
#define HSCROLL_ADR     0xf000

#define PALETTE_NUM(x)  (x<<13)
#define SPR_ATTR_HFLIP  0x0800
#define SPR_ATTR_VFLIP  0x1000



/* video memory layout:             */
/*  #0000..#bfff - 1536 patterns    */
/*  #c000..#c7ff - plane B (32x32)  */
/*  #c800..#dfff - 192 patterns     */
/*  #e000..#e7ff - plane A (32x32)  */
/*  #e800..#efff - 64 patterns      */
/*  #f000..#f3ff - hscroll table    */
/*  #f400..#fbff - 64 patterns      */
/*  #fc00..#fe7f - sprite attrs     */
/*  #fe80..#ffff - 12 patterns      */
/* 1868 patterns total              */

u16 screen_pal[64];
u16 needed_pal[64];

u16 comp60hz;

u16 read_gamepad(void);
void fade_into(u16*);
void update_palette();
void wait_sync(void);
u16 vram_copy(u16,const void*,u16);
u16 vram_fill(u16,u16,u16,u16);
void unpack_screen(const u8*);
void fade_screen(u16);
void tfc_init(const u8*);
void tfc_play(u16);
void psgfx_play(u16);
inline void busreq_on(void);
inline void busreq_off(void);
