#include "genesis.h"

#include "tfcplayer.h"
#include "psgplayer.h"

#include "gfx/sprites.h"
#include "gfx/tilesa.h"
#include "gfx/tilesb.h"
#include "gfx/tilesc.h"
#include "gfx/mojon.h"
#include "gfx/credits.h"
#include "gfx/title.h"
#include "gfx/gover.h"
#include "gfx/finscr.h"
#include "gfx/finbad.h"
#include "gfx/fingoo.h"
#include "gfx/finend.h"
#include "gfx/warp.h"

#include "snd/menu.h"
#include "snd/piramide.h"
#include "snd/zona1.h"
#include "snd/zona2.h"
#include "snd/zona3.h"
#include "snd/zona4.h"
#include "snd/fantasma.h"
#include "snd/gameover.h"
#include "snd/endingko.h"
#include "snd/endingok.h"
#include "snd/uwpsgfx.h"



volatile u32 vtimer;

u16 temp[32768/2];

u16 warp_palette[16];
u16 sprites_pal[16];
u16 tilesa_pal[16];
u16 tilesb_pal[16];
u16 tilesc_pal[16];



void aplib_decrunch(u8 *source, u8 *destination);

u16 depack(const u8* src,u16* dst)
{
	aplib_decrunch((u8*)src,(u8*)dst);

	return ((src[16]|(src[17]<<8))-1);
}



void _vblankcallback()
{
    if(!comp60hz||(comp60hz&&(vtimer%6)))
    {
        tfc_frame();
        psgfx_frame();
    }
}

void _hblankcallback()
{
}

/* initialize gamepads */

void init_gamepad()
{
    volatile u8 *pb;

    pb=(u8*)PORT_CTRL1;
    *pb=0x40;
    pb+=2;
    *pb=0x40;
    pb+=2;
    *pb=0x40;
}



/* read gamepad #1 */

u16 read_gamepad()
{
    volatile u8 *pb;
    u16 i,j;

    pb=(u8*)PORT_DATA1;

    *pb=0x40;        /* check gamepad */
    asm("nop");
    asm("nop");
    i=*pb&0x3f;

    *pb=0;           /* check buttons */
    asm("nop");
    asm("nop");
    j=(*pb&0x30)<<2;

    return(~(i|j));
}

/* initilize VDP */

void init_vdp(void)
{
    volatile u16 *pd,*pw;
    volatile u32 *pl;

    pw=(u16*)GFXCNTL;
    pl=(u32*)GFXCNTL;
    pd=(u16*)GFXDATA;

    *pw=0x8006;/* disable line interrupt */
    *pw=0x8134|(SCREEN_CHR_HGT==30?0x08:0x00);/* enable frame interrupt and dma, disable screen */
    *pw=0x8200|((PLANE_A_ADR>>10)&0x38);/* plane A at #e000 */
    *pw=0x8338;/* window plane not used */
    *pw=0x8400|(PLANE_B_ADR>>13);/* plane B at #c000 */
    *pw=0x8500|((SPRITES_ADR>>9)&0x7f);/* sprite attributes at #fc00 */
    *pw=0x8600;/* reserved */
    *pw=0x8700;/* background color */
    *pw=0x8800;/* reserved */
    *pw=0x8900;/* reserved */
    *pw=0x8a00;/* line interrupt not used */
    *pw=0x8b00;/* ie2 disabled, cell scroll disabled */
    *pw=0x8c00|(SCREEN_CHR_WDT==40?0x81:00);/* S/TE disabled */
    *pw=0x8d00|((HSCROLL_ADR>>10)&0x3f);/* hscroll table */
    *pw=0x8f02;/* autoincrement=2 */
    *pw=0x9000|((PLANE_WDT>>6)&0x03)|((PLANE_HGT>>2)&0x30);/* planes size */
    *pw=0x9100;/* window not used */
    *pw=0x9200;/* window not used */

    *pw=0x8f20;/* hscroll */
    *pl=GFX_WRITE_VRAM(HSCROLL_ADR);
    *pd=0;
    *pd=0;

    *pw=0x8f02;/* vscroll */
    *pl=GFX_WRITE_VSRAM(0);
    *pw=0;
    *pw=0;
}



void screen_enable(u16 enable)
{
    volatile u16 *pw;

    pw=(u16*)GFXCNTL;
    *pw=0x8134|(SCREEN_CHR_HGT==30?0x08:0x00)|(enable?0x40:0x00);/* enable frame interrupt and dma */
}



/* fade into a given palette */

void fade_into(u16 *palette)
{
    volatile u16 *pptr,*sptr;
    u16 j,c,cc,sc,pc;

    pptr=palette;
    sptr=screen_pal;

    for(j=0;j<64;j++)
    {
        sc=*sptr;
        pc=*pptr++;

        c=sc&0x0f00;
        cc=pc&0x0f00;
        if(c<cc) sc+=0x0100;
        if(c>cc) sc-=0x0100;

        c=sc&0x00f0;
        cc=pc&0x00f0;
        if(c<cc) sc+=0x0010;
        if(c>cc) sc-=0x0010;

        c=sc&0x000f;
        cc=pc&0x000f;
        if(c<cc) sc+=0x0001;
        if(c>cc) sc-=0x0001;

        *sptr++=sc;
    }
}



void update_palette(void)
{
    volatile u32 *pl;
    volatile u16 *pw;
    u16 i;

    pl=(u32*)GFXCNTL;
    pw=(u16*)GFXDATA;
    *pl=GFX_WRITE_CRAM(0);

    for(i=0;i<64;i++) *pw=screen_pal[i];
}



/* wait for VBL */

void wait_sync(void)
{
    volatile u16 *pw;
    u16 state;

    state=1<<3;
    pw=(u16*)GFXCNTL;

    while(state&(1<<3)) state=*pw;
    while(!(state&(1<<3))) state=*pw;

    if(comp60hz)
    {
        if(!(vtimer%6))
        {
            while(state&(1<<3)) state=*pw;
            while(!(state&(1<<3))) state=*pw;
        }
    }
}



inline void busreq_on(void)
{
	volatile u16 *pw;
	
	*((u16*)Z80_HALT)=0x100;
    pw=(u16*)Z80_HALT;
	//while(*pw&0x100);
}



inline void busreq_off(void)
{
	*((u16*)Z80_HALT)=0;
}



/* copy RAM>VRAM */

u16 vram_copy(u16 adr,const void *data,u16 size)
{
    volatile u16 *pw;
    volatile u32 *pl;
    u32 src;

    pw=(u16*)GFXCNTL;
    *pw=0x9300+((size>>1)&0xff);
    *pw=0x9400+((size>>9)&0xff);
    src=(u32)data;
    *pw=0x9500+((src>>1)&0xff);
    *pw=0x9600+((src>>9)&0xff);
    *pw=0x9700+((src>>17)&0x7f);

    busreq_on();

    pl=(u32*)GFXCNTL;
    *pl=GFX_DMA_VRAM((u32)adr);

    busreq_off();

    return adr+size;
}



/* fill VRAM */

u16 vram_fill(u16 adr,u16 val,u16 size,u16 delta)
{
    volatile u16 *pw;
    volatile u32 *pl;
    u16 i;

    pl=(u32*)GFXCNTL;
    pw=(u16*)GFXDATA;

    *pl=GFX_WRITE_VRAM(adr);

    if(!delta)
    {
        for(i=0;i<size;i++) *pw=val;
    }
    else
    {
        for(i=0;i<size;i++)
        {
            *pw=val;
            val+=delta;
        }
    }

    return adr+(size<<1);
}



/* unpack screen to VRAM */

void unpack_palette(u16 *pal)
{
	u16 i,col;

    for(i=0;i<16;i++)
    {
        col=temp[i];
        col=(col>>8)|(col<<8);
        *pal++=col;
    }
}

void unpack_screen(const u8 *data)
{
    volatile u16 *pw;
    volatile u32 *pl;
    u16 i;
    u16 adr;
    u16 twolayer;

    twolayer=0;
    if(data==title_data) twolayer=1;
    if(data==finbad_data||data==fingoo_data) twolayer=2;

    screen_enable(FALSE);

    pl=(u32*)GFXCNTL;
    pw=(u16*)GFXDATA;

    adr=PLANE_A_ADR;
    adr=vram_fill(adr,1600,32*2,0);
    adr=vram_fill(adr,256+PALETTE_NUM(2),32*24,1);
    vram_fill(adr,1600,32*2,0);
    vram_fill(PLANE_B_ADR,1600,32*28,0);

    if(twolayer)
    {
        adr=PLANE_B_ADR+(twolayer==1?9*32+8:2*32+1)*2;
        for(i=0;i<16;i++)
        {
            vram_fill(adr+i*32*2,1024+i*16+PALETTE_NUM(3),16,1);
        }

        depack((twolayer==1?warp_data:finscr_data),temp);
        unpack_palette(warp_palette);
        vram_copy(1024*32,&temp[16],16*16*32);
    }

    depack(data,temp);
    vram_copy(256*32,&temp[16],32*24*32);
    vram_fill(1600*32,0,32/2,0);

    screen_enable(TRUE);

    unpack_palette(&needed_pal[0x20]);

    for(i=0;i<16;i++)
    {
        needed_pal[i+0x00]=0;
        needed_pal[i+0x10]=0;
        //needed_pal[i+0x20]=col;
        needed_pal[i+0x30]=twolayer?warp_palette[i]:0;
    }

    for(i=0;i<16;i++)
    {
        fade_into(needed_pal);
        wait_sync();
		update_palette();
    }

    for(i=0;i<16;i++) needed_pal[i+0x30]=tilesc_pal[i];
}

/* fade out screen */

void fade_screen(u16 out)
{
    u16 i;

    if(out)
    {
        for(i=0;i<64;i++) needed_pal[i]=0;
    }
    else
    {
        for(i=0;i<16;i++)
        {
            needed_pal[i+0x00]=sprites_pal[i];
            needed_pal[i+0x10]=tilesa_pal[i];
            needed_pal[i+0x20]=tilesb_pal[i];
            needed_pal[i+0x30]=tilesc_pal[i];
        }
    }

    for(i=0;i<16;i++)
    {
        fade_into(needed_pal);
        wait_sync();
		update_palette();
    }
}



void uwol_preinit_variables(void);
void uwol_main(void);
void sp_Init(void);
void fases_init(void);

int main()
{
    volatile u8 *pb;
    u16 i;
    u16 adr,size;

    pb=(u8*)HW_VER;
    comp60hz=*pb&0x40?FALSE:TRUE;

    init_vdp();
    init_gamepad();

    tfc_init(NULL);
    psgfx_init(uwpsgfx_data);

    for(i=0;i<64;i++)
    {
        needed_pal[i]=0;
        screen_pal[i]=0;
    }
	
	update_palette();
	vram_fill(0,0,65535,0);

    adr=32;
    size=depack(tilesa_data,temp);
    unpack_palette(tilesa_pal);
    adr=vram_copy(adr,&temp[16],size-32);
    size=depack(tilesb_data,temp);
    unpack_palette(tilesb_pal);
    adr=vram_copy(adr+16*32,&temp[16],size-32);
    size=depack(tilesc_data,temp);
    unpack_palette(tilesc_pal);
    vram_copy(adr,&temp[16],size-32);
    size=depack(sprites_data,temp);
    unpack_palette(sprites_pal);
    vram_copy(152*32,&temp[16],size-32);

    screen_enable(TRUE);

    sp_Init();
    fases_init();
    uwol_preinit_variables();
    uwol_main();

    return 0;
}
